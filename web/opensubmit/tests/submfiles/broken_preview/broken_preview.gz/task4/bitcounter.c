
#include <stdio.h>
 
int main(int argc, char *argv[])
{
    long num,remainder,base = 1,binary = 0, no_of_1s = 0;
 
    num =strtol(argv[1], NULL, 0);

    while (num > 0)
    {
        remainder = num % 2;
       
        if (remainder == 1)
        {
            no_of_1s++;
        }

        binary = binary + remainder * base;
        num = num / 2;
        base = base * 10;
    }
    
    printf("No.of 1's in the binary number is = %ld\n", no_of_1s);
return 0;
}


