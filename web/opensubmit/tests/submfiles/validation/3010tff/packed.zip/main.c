#include "lib.h"
#include <stdio.h>

int main() {
    printf("%u\n",add(1,2));
    return 0;
}

