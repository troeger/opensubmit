int add(int arg1, int arg2) {
     return arg1+arg2;
}

