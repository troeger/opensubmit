#include <stdio.h>
#include <stdlib.h>                                     //header added for the use of atoi()
int main(int argc, char *argv[])
{
    int count, num;                                     //the count variable counts the number of 1 bits
    count=0;
    if(argc==2)
    {
        num=atoi(argv[1]);                              //the value in argv[1] is converted to type int and saved in the variable num
        while(num>0)
        {
            count= count + (num & 1);                   //the count variable is incremented if the last bit in num is 1
            num= num>>1;                                //the value in the variable num is shifted to the right by 1 bit
        }
        printf("%d\n",count);                           //the count of 1 bits is displayed
    }
    else
        printf("Incorrect syntax \n");                  //an error message is displayed if no argument or more than 1 argument is passed
    return 0;
}